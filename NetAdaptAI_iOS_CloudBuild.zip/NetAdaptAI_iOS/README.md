# NetAdapt AI iOS 0.1
SwiftUI-based iOS network diagnostic prototype.


## Features
- HTTPS HEAD probes for preset services
- Custom URL probe
- Response status and latency
- Heuristic diagnostic summary
- Local history via UserDefaults

## Limitations
Diagnostics only: does not intercept, modify, or reroute traffic from other apps and does not bypass filtering. Some services may reject HEAD requests.

## Build
Open `NetAdaptAI.xcodeproj` with Xcode. GitHub Actions is configured to compile the iOS Simulator target and package the simulator `.app` as an artifact.
